#define VERSION "release 1.99.06"
